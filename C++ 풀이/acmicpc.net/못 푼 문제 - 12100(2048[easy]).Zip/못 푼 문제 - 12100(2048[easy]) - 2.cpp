#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>


using namespace std;

int dy[] = { -1,1,0,0 };
int dx[] = { 0,0,-1,1 };
//�Ʒ� �� �� ��

int n;

void moveMap(vector<vector<int>>& board, vector<int>& dir) {

	vector<vector<int>> newBoard;
	int y, x;

	cout << '\n';
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			cout.width(3);
			cout << board[i][j] << ' ';
		}
		cout << '\n';
	}

	vector<int> stk;

	for (int d : dir) {
		newBoard.assign(n, vector<int>(n, 0));

		if (d == 1) {
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					if (board[j][i] > 0) {
						if (!stk.empty() && stk.back() == board[j][i]) {
							stk.back() *= -2;
						}
						else {
							stk.push_back(board[j][i]);
						}
					}
				}

				y = n - 1;
				for (; !stk.empty();) {
					newBoard[y--][i] = abs(stk.back());
					stk.pop_back();
				}
			}
		}
		else if (d == 3) {
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n; j++) {
					if (board[i][j] > 0) {
						if (!stk.empty() && stk.back() == board[i][j]) {
							stk.back() *= -2;
						}
						else {
							stk.push_back(board[i][j]);
						}
					}
				}

				x = n - 1;
				for (; !stk.empty();) {
					newBoard[i][x--] = abs(stk.back());
					stk.pop_back();
				}
			}
		}
		else if (d == 0) {
			for (int i = 0; i < n; i++) {
				for (int j = n - 1; j >= 0; j--) {
					if (board[j][i] > 0) {
						if (!stk.empty() && stk.back() == board[j][i]) {
							stk.back() *= -2;
						}
						else {
							stk.push_back(board[j][i]);
						}
					}
				}

				y = 0;
				for (; !stk.empty();) {
					newBoard[y++][i] = abs(stk.back());
					stk.pop_back();
				}
			}

		}
		else if (d == 2) {
			for (int i = 0; i < n; i++) {
				for (int j = n - 1; j >= 0; j--) {
					if (board[i][j] > 0) {
						if (!stk.empty() && stk.back() == board[i][j]) {
							stk.back() *= -2;
						}
						else {
							stk.push_back(board[i][j]);
						}
					}
				}

				x = 0;
				for (; !stk.empty();) {
					newBoard[i][x++] = abs(stk.back());
					stk.pop_back();
				}
			}
		}
		board = newBoard;

		cout << '\n';
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				cout.width(3);
				cout << newBoard[i][j] << ' ';
			}
			cout << '\n';
		}
	}

}

int main() {
	cin.tie(NULL);
	cout.tie(NULL);
	ios::sync_with_stdio(false);

	cin >> n;

	vector<vector<int>> board(n, vector<int>(n, 0));
	vector<vector<int>> newBoard;

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			cin >> board[i][j];
		}
	}

	vector<int> dir;

	int ans = 0;

	for (int bitCase = 0; bitCase < 1; bitCase++) {
		dir.clear();

		dir = { 0 ,2 ,3 ,0 ,2 };

		newBoard = board;

		moveMap(newBoard, dir);

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				ans = max(newBoard[i][j], ans);
			}
		}

	}

	cout << ans;
	return 0;
}

//https://www.acmicpc.net/board/view/61812

//https://www.acmicpc.net/board/view/14579	

//0 2 3 0 2
//0 3 3 0 2
//0 2 3 0 3
//0 3 3 0 3