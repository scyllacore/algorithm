#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

int dy[] = { -1,1,0,0 };
int dx[] = { 0,0,-1,1 };
//�Ʒ� �� �� ��

int n;

void moveMap(vector<vector<int>>& board, vector<int>& dir) {

	vector<vector<int>> newBoard;
	int y, x;

	for (int d : dir) {
		newBoard.assign(n, vector<int>(n, 0));

		if (d == 1) {
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n - 1; j++) {
					swap(board[j + 1][i], board[j][i]);
					if (board[j + 1][i] == board[j][i]) {
						board[j + 1][i] += board[j][i];
						board[j][i] = 0;
					}
				}
			}

			for (int i = 0; i < n; i++) {
				y = n - 1;
				for (int j = n - 1; j >= 0; j--) {
					if (board[j][i] != 0) {
						newBoard[y--][i] = board[j][i];
					}
				}
			}

		}
		else if (d == 3) {
			for (int i = 0; i < n; i++) {
				for (int j = 0; j < n - 1; j++) {

					swap(board[i][j + 1], board[i][j]);

					if (board[i][j + 1] == board[i][j]) {
						board[i][j + 1] += board[i][j];
						board[i][j] = 0;
					}
				}
			}

			for (int i = 0; i < n; i++) {
				x = n - 1;
				for (int j = n - 1; j >= 0; j--) {
					if (board[i][j] != 0) {
						newBoard[i][x--] = board[i][j];
					}
				}
			}

		}
		else if (d == 0) {
			for (int i = 0; i < n; i++) {
				for (int j = n - 1; j >= 1; j--) {

					swap(board[j - 1][i], board[j][i]);

					if (board[j - 1][i] == board[j][i]) {
						board[j - 1][i] += board[j][i];
						board[j][i] = 0;
					}
				}
			}

			for (int i = 0; i < n; i++) {
				y = 0;
				for (int j = 0; j < n; j++) {
					if (board[j][i] != 0) {
						newBoard[y++][i] = board[j][i];
					}
				}
			}


		}
		else if (d == 2) {
			for (int i = 0; i < n; i++) {
				for (int j = n - 1; j >= 1; j--) {

					swap(board[i][j - 1], board[i][j]);

					if (board[i][j - 1] == board[i][j]) {
						board[i][j - 1] += board[i][j];
						board[i][j] = 0;
					}
				}
			}

			for (int i = 0; i < n; i++) {
				x = 0;
				for (int j = 0; j < n; j++) {
					if (board[i][j] != 0) {
						newBoard[i][x++] = board[i][j];
					}
				}
			}
		}

		board = newBoard;

	}

}

int main() {
	cin.tie(NULL);
	cout.tie(NULL);
	ios::sync_with_stdio(false);

	cin >> n;

	vector<vector<int>> board(n, vector<int>(n, 0));
	vector<vector<int>> newBoard;

	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			cin >> board[i][j];
		}
	}

	vector<int> dir;

	int ans = 0;

	for (int bitCase = 0; bitCase < (1 << 10); bitCase++) {
		dir.clear();

		for (int i = 0; i < 10; i += 2) {
			int dirVal = bitCase & (1 << i + 1) ? 2 : 0;
			dirVal += bitCase & (1 << i) ? 1 : 0;

			dir.push_back(dirVal);
		}

		newBoard = board;

		moveMap(newBoard, dir);

		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++) {
				ans = max(newBoard[i][j], ans);
			}
		}
	}

	cout << ans;
	return 0;
}

//https://www.acmicpc.net/board/view/61812